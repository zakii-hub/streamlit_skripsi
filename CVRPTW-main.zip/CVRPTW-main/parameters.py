ALPHA = 0.95
BETA = 0.001
INITIAL_TEMPERATURE = 100             # initial value of the temperature

